/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;


public class Paciente {
    String num_cedula;
    String apellidop;
    String apellidom;
    String nombre1;
    String nombre2;
    String nombre_poder;
    String direccion;
    String ciudad;
    String provincia;
    String fecha_nacimiento;
    String telefono;
    String seguro_social;
    String relacion_paciente;
    String alergias;

    public Paciente(String num_cedula, String apellidop, String apellidom, String nombre1, String nombre2, String nombre_poder, String direccion, String ciudad, String provincia, String fecha_nacimiento, String telefono, String seguro_social, String relacion_paciente, String alergias) {
        this.num_cedula = num_cedula;
        this.apellidop = apellidop;
        this.apellidom = apellidom;
        this.nombre1 = nombre1;
        this.nombre2 = nombre2;
        this.nombre_poder = nombre_poder;
        this.direccion = direccion;
        this.ciudad = ciudad;
        this.provincia = provincia;
        this.fecha_nacimiento = fecha_nacimiento;
        this.telefono = telefono;
        this.seguro_social = seguro_social;
        this.relacion_paciente = relacion_paciente;
        this.alergias = alergias;
    }

    public String getNum_cedula() {
        return num_cedula;
    }

    public void setNum_cedula(String num_cedula) {
        this.num_cedula = num_cedula;
    }

    public String getApellidop() {
        return apellidop;
    }

    public void setApellidop(String apellidop) {
        this.apellidop = apellidop;
    }

    public String getApellidom() {
        return apellidom;
    }

    public void setApellidom(String apellidom) {
        this.apellidom = apellidom;
    }

    public String getNombre1() {
        return nombre1;
    }

    public void setNombre1(String nombre1) {
        this.nombre1 = nombre1;
    }

    public String getNombre2() {
        return nombre2;
    }

    public void setNombre2(String nombre2) {
        this.nombre2 = nombre2;
    }

    public String getNombre_poder() {
        return nombre_poder;
    }

    public void setNombre_poder(String nombre_poder) {
        this.nombre_poder = nombre_poder;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getProvincia() {
        return provincia;
    }

    public void setProvincia(String provincia) {
        this.provincia = provincia;
    }

    public String getFecha_nacimiento() {
        return fecha_nacimiento;
    }

    public void setFecha_nacimiento(String fecha_nacimiento) {
        this.fecha_nacimiento = fecha_nacimiento;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getSeguro_social() {
        return seguro_social;
    }

    public void setSeguro_social(String seguro_social) {
        this.seguro_social = seguro_social;
    }

    public String getRelacion_paciente() {
        return relacion_paciente;
    }

    public void setRelacion_paciente(String relacion_paciente) {
        this.relacion_paciente = relacion_paciente;
    }

    public String getAlergias() {
        return alergias;
    }

    public void setAlergias(String alergias) {
        this.alergias = alergias;
    }
    
    
}
