/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class GestorBD {

    private Connection conexion = null;
    private Statement stm = null;
    private ResultSet pacienteResultSet;
    private int resultUpdate = 0;
    String num_cedula;
    String apellidop;
    String apellidom;
    String nombre1;
    String nombre2;
    String nombre_poder;
    String direccion;
    String ciudad;
    String provincia;
    String fecha_nacimiento;
    String telefono;
    String seguro_social;
    String relacion_paciente;
    String alergias;

    public ArrayList<Paciente> leerExistentes() {
        ArrayList<Paciente> pacientes = new ArrayList<Paciente>();
        try {
            ConectaBD conectaBD = new ConectaBD();
            conexion = conectaBD.getConexion();
            stm = conexion.createStatement();
            pacienteResultSet = stm.executeQuery("select * from pacientes");
            Paciente pacientehallado;
            if (!pacienteResultSet.next()) {
                System.out.println(" No se encontraron registros");
                conexion.close();
                return null;
            } else {
                do {
                    num_cedula = pacienteResultSet.getString("num_cedula");
                    apellidop = pacienteResultSet.getString("apellidop");
                    apellidom = pacienteResultSet.getString("apellidom");
                    nombre1 = pacienteResultSet.getString("nombre1");
                    nombre2 = pacienteResultSet.getString("nombre2");
                    nombre_poder = pacienteResultSet.getString("nombre_poder");
                    direccion = pacienteResultSet.getString("direccion");
                    ciudad = pacienteResultSet.getString("ciudad");
                    provincia = pacienteResultSet.getString("provincia");
                    fecha_nacimiento = pacienteResultSet.getString("fecha_nacimiento");
                    telefono = pacienteResultSet.getString("telefono");
                    seguro_social = pacienteResultSet.getString("seguro_social");
                    relacion_paciente = pacienteResultSet.getString("relacion_paciente");
                    alergias = pacienteResultSet.getString("alergias");
                    pacientehallado = new Paciente(num_cedula, apellidop, apellidom, nombre1, nombre2, nombre_poder, direccion, ciudad, provincia, fecha_nacimiento, telefono, seguro_social, relacion_paciente, alergias);
                    pacientes.add(pacientehallado);
                } while (pacienteResultSet.next());
                conexion.close();
                return pacientes;
            }
        } catch (Exception e) {
            System.out.println("Error en la base de datos.");
            e.printStackTrace();
            return null;
        }
    }

    public boolean guardarPaciente(Paciente pacienteNuevo) {
        try {
            ConectaBD conectaBD = new ConectaBD();
            conexion = conectaBD.getConexion();
            stm = conexion.createStatement();
            if (pacienteNuevo.getNum_cedula().isEmpty() || pacienteNuevo.getNombre1().isEmpty() || pacienteNuevo.getNombre2().isEmpty() || pacienteNuevo.getApellidop().isEmpty() || pacienteNuevo.getApellidom().isEmpty()) {
                return false;
            } else {
                resultUpdate = stm.executeUpdate("INSERT INTO pacientes VALUES('"
                        + pacienteNuevo.getNum_cedula()
                        + "','" + pacienteNuevo.getApellidop()
                        + "','" + pacienteNuevo.getApellidom()
                        + "','" + pacienteNuevo.getNombre1()
                        + "','" + pacienteNuevo.getNombre2()
                        + "','" + pacienteNuevo.getNombre_poder()
                        + "','" + pacienteNuevo.getDireccion()
                        + "','" + pacienteNuevo.getCiudad()
                        + "','" + pacienteNuevo.getProvincia()
                        + "','" + pacienteNuevo.getFecha_nacimiento()
                        + "','" + pacienteNuevo.getTelefono()
                        + "','" + pacienteNuevo.getSeguro_social()
                        + "','" + pacienteNuevo.getRelacion_paciente()
                        + "','" + pacienteNuevo.getAlergias()
                        + "');");
                if (resultUpdate != 0) {
                    conexion.close();
                    return true;
                } else {
                    conexion.close();
                    System.out.println("No se pudo insertar el Paciente.");
                    return false;
                }
            }
        } catch (Exception e) {
            System.out.println("Error en la base de datos.");
            e.printStackTrace();
            return false;
        }

    }

    public boolean borrarPaciente(Paciente pacienteBorrar) {
        try {
            ConectaBD conectaBD = new ConectaBD();
            conexion = conectaBD.getConexion();
            stm = conexion.createStatement();
            resultUpdate = stm.executeUpdate("DELETE FROM pacientes WHERE(num_cedula = '" + pacienteBorrar.getNum_cedula()
                    + "');");
            if (resultUpdate != 0) {
                conexion.close();
                return true;
            } else {
                conexion.close();;
                System.out.println("No se pudo borrar el paciente.");
                return false;
            }
        } catch (Exception e) {
            System.out.println("Error en la base de datos.");
            e.printStackTrace();
            return false;
        }
    }

    public Paciente localizaPaciente(String cedula) {
        try {
            ConectaBD conectaBD = new ConectaBD();
            conexion = conectaBD.getConexion();
            stm = conexion.createStatement();
            pacienteResultSet = stm.executeQuery("SELECT * FROM pacientes WHERE(num_cedula = '"
                    + cedula + "');");
            if (pacienteResultSet.next()) {
                num_cedula = pacienteResultSet.getString("num_cedula");
                apellidop = pacienteResultSet.getString("apellidop");
                apellidom = pacienteResultSet.getString("apellidom");
                nombre1 = pacienteResultSet.getString("nombre1");
                nombre2 = pacienteResultSet.getString("nombre2");
                nombre_poder = pacienteResultSet.getString("nombre_poder");
                direccion = pacienteResultSet.getString("direccion");
                ciudad = pacienteResultSet.getString("ciudad");
                provincia = pacienteResultSet.getString("provincia");
                fecha_nacimiento = pacienteResultSet.getString("fecha_nacimiento");
                telefono = pacienteResultSet.getString("telefono");
                seguro_social = pacienteResultSet.getString("seguro_social");
                relacion_paciente = pacienteResultSet.getString("relacion_paciente");
                alergias = pacienteResultSet.getString("alergias");
                Paciente pacientehallado = new Paciente(num_cedula, apellidop, apellidom, nombre1, nombre2, nombre_poder, direccion, ciudad, provincia, fecha_nacimiento, telefono, seguro_social, relacion_paciente, alergias);
                conexion.close();
                return pacientehallado;
            } else {
                System.out.println(" No se encontraron registros");
                conexion.close();
                return null;
            }
        } catch (Exception e) {
            System.out.println("Error en la base de datos.");
            e.printStackTrace();
            return null;
        }
    }

    public boolean modificarPaciente(Paciente pacienteACambiar) {
        try {
            ConectaBD conectaBD = new ConectaBD();
            conexion = conectaBD.getConexion();
            stm = conexion.createStatement();
            resultUpdate = stm.executeUpdate("UPDATE pacientes SET nombre1 = '"
                    + pacienteACambiar.getNombre1()
                    + "', nombre2 = '" + pacienteACambiar.getNombre2()
                    + "', apellidop = '" + pacienteACambiar.getApellidop()
                    + "', apellidom = '" + pacienteACambiar.getApellidom()
                    + "', nombre_poder = '" + pacienteACambiar.getNombre_poder()
                    + "', direccion = '" + pacienteACambiar.getDireccion()
                    + "', ciudad = '" + pacienteACambiar.getCiudad()
                    + "', provincia = '" + pacienteACambiar.getProvincia()
                    + "', fecha_nacimiento = '" + pacienteACambiar.getFecha_nacimiento()
                    + "', telefono = '" + pacienteACambiar.getTelefono()
                    + "', seguro_social = '" + pacienteACambiar.getSeguro_social()
                    + "', relacion_paciente = '" + pacienteACambiar.getRelacion_paciente()
                    + "', alergias = '" + pacienteACambiar.getAlergias()
                    + "' WHERE num_cedula = "
                    + pacienteACambiar.getNum_cedula() + ";");
            if (resultUpdate != 0) {
                conexion.close();
                return true;
            } else {
                conexion.close();;
                System.out.println("No se pudo modificar el paciente.");
                return false;
            }
        } catch (Exception e) {
            System.out.println("Error en la base de datos.");
            e.printStackTrace();
            return false;
        }
    }

}
