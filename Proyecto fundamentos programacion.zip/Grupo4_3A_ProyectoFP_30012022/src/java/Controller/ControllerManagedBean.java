/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.io.IOException;
import Model.GestorBD;
import Model.Paciente;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

@ManagedBean(name = "controllerManagedBean")
@SessionScoped
public class ControllerManagedBean {

    String num_cedula;
    String apellidop;
    String apellidom;
    String nombre1;
    String nombre2;
    String nombre_poder;
    String direccion;
    String ciudad;
    String provincia;
    String fecha_nacimiento;
    String telefono;
    String seguro_social;
    String relacion_paciente;
    String alergias;
    private GestorBD gestorBD;
    private ArrayList<Paciente> pacienteList;

    public ControllerManagedBean() {
        gestorBD = new GestorBD();
        pacienteList = gestorBD.leerExistentes();
    }

    public String getNum_cedula() {
        return num_cedula;
    }

    public void setNum_cedula(String num_cedula) {
        this.num_cedula = num_cedula;
    }

    public String getApellidop() {
        return apellidop;
    }

    public void setApellidop(String apellidop) {
        this.apellidop = apellidop;
    }

    public String getApellidom() {
        return apellidom;
    }

    public void setApellidom(String apellidom) {
        this.apellidom = apellidom;
    }

    public String getNombre1() {
        return nombre1;
    }

    public void setNombre1(String nombre1) {
        this.nombre1 = nombre1;
    }

    public String getNombre2() {
        return nombre2;
    }

    public void setNombre2(String nombre2) {
        this.nombre2 = nombre2;
    }

    public String getNombre_poder() {
        return nombre_poder;
    }

    public void setNombre_poder(String nombre_poder) {
        this.nombre_poder = nombre_poder;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getProvincia() {
        return provincia;
    }

    public void setProvincia(String provincia) {
        this.provincia = provincia;
    }

    public String getFecha_nacimiento() {
        return fecha_nacimiento;
    }

    public void setFecha_nacimiento(String fecha_nacimiento) {
        this.fecha_nacimiento = fecha_nacimiento;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getSeguro_social() {
        return seguro_social;
    }

    public void setSeguro_social(String seguro_social) {
        this.seguro_social = seguro_social;
    }

    public String getRelacion_paciente() {
        return relacion_paciente;
    }

    public void setRelacion_paciente(String relacion_paciente) {
        this.relacion_paciente = relacion_paciente;
    }

    public String getAlergias() {
        return alergias;
    }

    public void setAlergias(String alergias) {
        this.alergias = alergias;
    }

    public void setPacienteList(ArrayList<Paciente> pacienteList) {
        this.pacienteList = pacienteList;
    }
    public ArrayList<Paciente> getPacienteList() {
        return pacienteList;
    }

    public void pedirDatosPaciente_aAgregar() {
        inicializar();
        try {
            FacesContext.getCurrentInstance()
                    .getExternalContext()
                    .redirect("agregar_Paciente.xhtml");
        } catch (IOException ex) {
            Logger.getLogger(ControllerManagedBean.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void regresar_Inicio() {
        try {
            FacesContext.getCurrentInstance()
                    .getExternalContext()
                    .redirect("index.xhtml");
        } catch (IOException ex) {
            Logger.getLogger(ControllerManagedBean.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void irListado() {
        try {
            FacesContext.getCurrentInstance()
                    .getExternalContext()
                    .redirect("listado_Pacientes.xhtml");
        } catch (IOException ex) {
            Logger.getLogger(ControllerManagedBean.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void guardarPaciente() {
        try {
            Paciente pacienteNuevo = new Paciente(num_cedula, apellidop, apellidom, nombre1, nombre2, nombre_poder, direccion, ciudad, provincia, fecha_nacimiento, telefono, seguro_social, relacion_paciente, alergias);
            if (gestorBD.guardarPaciente(pacienteNuevo)) {
                try {
                    pacienteList = gestorBD.leerExistentes();
                    FacesContext.getCurrentInstance()
                            .getExternalContext()
                            .redirect("listado_Pacientes.xhtml");
                } catch (IOException ex) {
                    Logger.getLogger(ControllerManagedBean.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else {
                try {
                    FacesContext.getCurrentInstance()
                            .getExternalContext()
                            .redirect("errorRegistro.xhtml");
                } catch (IOException ex) {
                    Logger.getLogger(ControllerManagedBean.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        } catch (Exception e) {
            try {
                FacesContext.getCurrentInstance()
                        .getExternalContext()
                        .redirect("errorRegistro.xhtml");
            } catch (IOException ex) {
                Logger.getLogger(ControllerManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

    public void pedirDatosPaciente_aBorrar() {
        num_cedula = "";
        try {
            FacesContext.getCurrentInstance()
                    .getExternalContext()
                    .redirect("borrar_Paciente.xhtml");
        } catch (IOException ex) {
            Logger.getLogger(ControllerManagedBean.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void borrarPaciente() {
        Paciente pacienteABorrar = new Paciente(num_cedula, apellidop, apellidom, nombre1, nombre2, nombre_poder, direccion, ciudad, provincia, fecha_nacimiento, telefono, seguro_social, relacion_paciente, alergias);
        if (gestorBD.borrarPaciente(pacienteABorrar)) {
            try {
                pacienteList = gestorBD.leerExistentes();
                FacesContext.getCurrentInstance()
                        .getExternalContext()
                        .redirect("listado_Pacientes.xhtml");
            } catch (IOException ex) {
                Logger.getLogger(ControllerManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            try {
                pacienteList = gestorBD.leerExistentes();
                FacesContext.getCurrentInstance()
                        .getExternalContext()
                        .redirect("error.xhtml");
            } catch (IOException ex) {
                Logger.getLogger(ControllerManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public void pedirDatosPaciente_aModificar() {
        num_cedula = "";
        try {
            FacesContext.getCurrentInstance()
                    .getExternalContext()
                    .redirect("select_pacienteAModificar.xhtml");
        } catch (IOException ex) {
            Logger.getLogger(ControllerManagedBean.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void localizarPaciente() {
        Paciente pacientelocalizado = gestorBD.localizaPaciente(num_cedula);
        if (pacientelocalizado != null) {
            try {
                obtenerPaciente(pacientelocalizado);
                FacesContext.getCurrentInstance()
                        .getExternalContext()
                        .redirect("modificar_Paciente.xhtml");
            } catch (IOException ex) {
                Logger.getLogger(ControllerManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            try {
                pacienteList = gestorBD.leerExistentes();
                FacesContext.getCurrentInstance()
                        .getExternalContext()
                        .redirect("error.xhtml");
            } catch (IOException ex) {
                Logger.getLogger(ControllerManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public void pedirDatosPaciente_aConsultar() {
        num_cedula = "";
        try {
            FacesContext.getCurrentInstance()
                    .getExternalContext()
                    .redirect("select_pacienteAConsultar.xhtml");
        } catch (IOException ex) {
            Logger.getLogger(ControllerManagedBean.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void consultarPaciente() {
        Paciente pacienteconsultado = gestorBD.localizaPaciente(num_cedula);
        if (pacienteconsultado != null) {
            try {
                obtenerPaciente(pacienteconsultado);
                FacesContext.getCurrentInstance()
                        .getExternalContext()
                        .redirect("consultar_Paciente.xhtml");
            } catch (IOException ex) {
                Logger.getLogger(ControllerManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            try {
                pacienteList = gestorBD.leerExistentes();
                FacesContext.getCurrentInstance()
                        .getExternalContext()
                        .redirect("error.xhtml");
            } catch (IOException ex) {
                Logger.getLogger(ControllerManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public void modificarPaciente() {
        Paciente paciente_a_Cambiar = new Paciente(num_cedula, apellidop, apellidom, nombre1, nombre2, nombre_poder, direccion, ciudad, provincia, fecha_nacimiento, telefono, seguro_social, relacion_paciente, alergias);
        if (gestorBD.modificarPaciente(paciente_a_Cambiar)) {
            try {
                pacienteList = gestorBD.leerExistentes();
                FacesContext.getCurrentInstance().getExternalContext()
                        .redirect("listado_Pacientes.xhtml");
            } catch (IOException ex) {
                Logger.getLogger(ControllerManagedBean.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public void inicializar() {
        num_cedula = "";
        apellidop = "";
        apellidom = "";
        nombre1 = "";
        nombre2 = "";
        nombre_poder = "";
        direccion = "";
        ciudad = "";
        provincia = "";
        fecha_nacimiento = "";
        telefono = "";
        seguro_social = "";
        relacion_paciente = "";
        alergias = "";
    }

    public void obtenerPaciente(Paciente paciente) {
        num_cedula = paciente.getNum_cedula();
        apellidop = paciente.getApellidop();
        apellidom = paciente.getApellidom();
        nombre1 = paciente.getNombre1();
        nombre2 = paciente.getNombre2();
        nombre_poder = paciente.getNombre_poder();
        direccion = paciente.getDireccion();
        ciudad = paciente.getCiudad();
        provincia = paciente.getProvincia();
        fecha_nacimiento = paciente.getFecha_nacimiento();
        telefono = paciente.getTelefono();
        seguro_social = paciente.getSeguro_social();
        relacion_paciente = paciente.getRelacion_paciente();
        alergias = paciente.getAlergias();
    }

}
